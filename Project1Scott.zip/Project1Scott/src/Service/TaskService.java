package Service;

import java.util.HashMap;
import java.util.Map;

import model.Task;

public class TaskService {
    private Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        tasks.put(task.getTaskId(), task);
    }

    public void deleteTask(String taskId) {
        tasks.remove(taskId);
    }

    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }

    public void updateTask(String taskId, String name, String description) {
        Task task = tasks.get(taskId);
        if (task != null) {
            task.setName(name);
            task.setDescription(description);
        }
    }
}
