package model;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testContactConstructorAndGetters() {
        Contact contact = new Contact("C123", "John", "Doe", "1234567890", "123 Main St.");
        
        assertEquals("C123", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St.", contact.getAddress());
    }

    @Test
    public void testSetFirstName() {
        Contact contact = new Contact("C123", "John", "Doe", "1234567890", "123 Main St.");
        contact.setFirstName("Jane");
        assertEquals("Jane", contact.getFirstName());
    }

    @Test
    public void testSetLastName() {
        Contact contact = new Contact("C123", "John", "Doe", "1234567890", "123 Main St.");
        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName());
    }

    @Test
    public void testSetPhone() {
        Contact contact = new Contact("C123", "John", "Doe", "1234567890", "123 Main St.");
        contact.setPhone("0987654321");
        assertEquals("0987654321", contact.getPhone());
    }

    @Test
    public void testSetAddress() {
        Contact contact = new Contact("C123", "John", "Doe", "1234567890", "123 Main St.");
        contact.setAddress("456 Elm St.");
        assertEquals("456 Elm St.", contact.getAddress());
    }
}
