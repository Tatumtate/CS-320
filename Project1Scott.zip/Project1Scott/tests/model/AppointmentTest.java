package model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

public class AppointmentTest {

    @Test
    public void testAppointmentConstructorAndGetters() {
        Appointment appointment = new Appointment("A123", new Date(System.currentTimeMillis() + 10000), "Doctor Appointment");
        
        assertEquals("A123", appointment.getAppointmentId());
        assertNotNull(appointment.getAppointmentDate());
        assertEquals("Doctor Appointment", appointment.getDescription());
    }

    @Test
    public void testSetAppointmentDate() {
        Appointment appointment = new Appointment("A123", new Date(System.currentTimeMillis() + 10000), "Doctor Appointment");
        
        Date newDate = new Date(System.currentTimeMillis() + 20000);
        appointment.setAppointmentDate(newDate);
        
        assertEquals(newDate, appointment.getAppointmentDate());
    }

    @Test
    public void testSetAppointmentDateInPast() {
        Appointment appointment = new Appointment("A123", new Date(System.currentTimeMillis() + 10000), "Doctor Appointment");
        
        assertThrows(IllegalArgumentException.class, () -> {
            appointment.setAppointmentDate(new Date(System.currentTimeMillis() - 10000));
        });
    }

    @Test
    public void testSetDescription() {
        Appointment appointment = new Appointment("A123", new Date(System.currentTimeMillis() + 10000), "Doctor Appointment");
        appointment.setDescription("Dentist Appointment");
        assertEquals("Dentist Appointment", appointment.getDescription());
    }
}
