package model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TaskTest {

    @Test
    public void testTaskConstructorAndGetters() {
        Task task = new Task("T123", "Complete Homework", "Complete math homework by Monday");
        
        assertEquals("T123", task.getTaskId());
        assertEquals("Complete Homework", task.getName());
        assertEquals("Complete math homework by Monday", task.getDescription());
    }

    @Test
    public void testSetName() {
        Task task = new Task("T123", "Complete Homework", "Complete math homework by Monday");
        task.setName("Complete Assignment");
        assertEquals("Complete Assignment", task.getName());
    }

    @Test
    public void testSetDescription() {
        Task task = new Task("T123", "Complete Homework", "Complete math homework by Monday");
        task.setDescription("Complete science homework by Tuesday");
        assertEquals("Complete science homework by Tuesday", task.getDescription());
    }
}
