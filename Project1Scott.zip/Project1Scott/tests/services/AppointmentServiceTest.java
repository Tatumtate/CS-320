package services;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Service.AppointmentService;
import model.Appointment;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;

public class AppointmentServiceTest {

    private AppointmentService appointmentService;

    @BeforeEach
    public void setUp() {
        appointmentService = new AppointmentService();
    }

    @Test
    public void testAddAppointment() {
        Appointment appointment = new Appointment("A123", new Date(System.currentTimeMillis() + 10000), "Doctor Appointment");
        appointmentService.addAppointment(appointment);
        Appointment retrievedAppointment = appointmentService.getAppointment("A123");
        assertNotNull(retrievedAppointment);
        assertEquals("Doctor Appointment", retrievedAppointment.getDescription());
    }

    @Test
    public void testDeleteAppointment() {
        Appointment appointment = new Appointment("A123", new Date(System.currentTimeMillis() + 10000), "Doctor Appointment");
        appointmentService.addAppointment(appointment);
        appointmentService.deleteAppointment("A123");
        assertNull(appointmentService.getAppointment("A123"));
    }
}
