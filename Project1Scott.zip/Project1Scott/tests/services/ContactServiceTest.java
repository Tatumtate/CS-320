package services;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Service.ContactService;
import model.Contact;

import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
    }

    @Test
    public void testAddContact() {
        Contact contact = new Contact("C123", "John", "Doe", "1234567890", "123 Main St.");
        contactService.addContact(contact);
        Contact retrievedContact = contactService.getContact("C123");
        assertNotNull(retrievedContact);
        assertEquals("John", retrievedContact.getFirstName());
    }

    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("C123", "John", "Doe", "1234567890", "123 Main St.");
        contactService.addContact(contact);
        contactService.deleteContact("C123");
        assertNull(contactService.getContact("C123"));
    }

    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("C123", "John", "Doe", "1234567890", "123 Main St.");
        contactService.addContact(contact);
        contactService.updateContact("C123", "Jane", "Smith", "0987654321", "456 Elm St.");
        
        Contact updatedContact = contactService.getContact("C123");
        assertEquals("Jane", updatedContact.getFirstName());
        assertEquals("Smith", updatedContact.getLastName());
        assertEquals("0987654321", updatedContact.getPhone());
        assertEquals("456 Elm St.", updatedContact.getAddress());
    }
}
