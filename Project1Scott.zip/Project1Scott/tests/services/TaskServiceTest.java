package services;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import Service.TaskService;
import model.Task;

import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {

    private TaskService taskService;

    @BeforeEach
    public void setUp() {
        taskService = new TaskService();
    }

    @Test
    public void testAddTask() {
        Task task = new Task("T123", "Complete Homework", "Complete math homework by Monday");
        taskService.addTask(task);
        Task retrievedTask = taskService.getTask("T123");
        assertNotNull(retrievedTask);
        assertEquals("Complete Homework", retrievedTask.getName());
    }

    @Test
    public void testDeleteTask() {
        Task task = new Task("T123", "Complete Homework", "Complete math homework by Monday");
        taskService.addTask(task);
        taskService.deleteTask("T123");
        assertNull(taskService.getTask("T123"));
    }

    @Test
    public void testUpdateTask() {
        Task task = new Task("T123", "Complete Homework", "Complete math homework by Monday");
        taskService.addTask(task);
        taskService.updateTask("T123", "Complete Assignment", "Complete science homework by Tuesday");
        
        Task updatedTask = taskService.getTask("T123");
        assertEquals("Complete Assignment", updatedTask.getName());
        assertEquals("Complete science homework by Tuesday", updatedTask.getDescription());
    }
}
